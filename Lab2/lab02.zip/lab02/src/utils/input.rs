
use regex::Regex;
/// Validates if the given email address is properly formatted using the `validator` crate.
pub fn valid_email(em: &str) -> bool {
    regex::Regex::new(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
    .unwrap()
    .is_match(em)
}

/// Ensures the provided name consists only of alphabetic characters and spaces, adhering to a length constraint.
pub fn valid_name(nm: &str) -> bool {
    // Names should consist of alphabetic characters, spaces, and stay within the length limit.
    !nm.is_empty() && nm.len() <= 50 && nm.chars().all(|ch| ch.is_alphabetic() || ch.is_whitespace())
}

/// Confirms that the given ID is alphanumeric, allows dashes, and matches the required length.
pub fn valid_id(identifier: &str) -> bool {
    // IDs must be alphanumeric, can include dashes, and must meet the required length.
    identifier.len() == 36 && identifier.chars().all(|ch| ch.is_alphanumeric() || ch == '-')
}

/// Checks if the optional JSON value is a boolean, returning `false` if invalid or absent.
pub fn valid_bool(val: Option<&serde_json::Value>) -> bool {
    val.and_then(|v| v.as_bool()).unwrap_or(false) // Defaults to `false` for invalid or absent values.
}

/// Validates text fields to ensure they are non-empty and within a specified maximum length.
pub fn valid_text(txt: &str, max_len: usize) -> bool {
    // Text fields must be non-empty and not exceed the specified maximum length.
    !txt.is_empty() && txt.len() <= max_len
}
